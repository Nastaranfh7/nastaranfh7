import { authenticateExtra } from "../config/shopify.js";
import { json } from "@remix-run/node";
import Discounts from "../components/dicounts/index.jsx";
import { FeatureModel } from "../models/feature.model.js";
import { VolumeDiscountModel } from "../models/volumeDiscount.model.js";


const METAFIELD_NAMESPACE = "shipready";
const METAFIELD_KEY = "appSettings";
const METAFIELD_TYPE = "json";

export const loader = async ({ request }) => {
  const { metaobject, metafield } = await authenticateExtra(request);

  const url = new URL(request.url);
  const cursor = url.searchParams.get('cursor');
  const limit = 10; // You can adjust this or make it dynamic
  const volumeDiscounts = await metaobject.list(VolumeDiscountModel, limit, cursor);
  

  const features = await metaobject.list(FeatureModel);
  const currentAppMetafield = await metafield.getCurrentAppMetafield(
    METAFIELD_NAMESPACE,
    METAFIELD_KEY,
  );
  
  return json({
    settingsData: currentAppMetafield?.value
      ? JSON.parse(currentAppMetafield?.value)
      : {},
    features,
    volumeDiscounts
  });
  
};

export async function action({ request }) {
  const { metafield, metaobject } = await authenticateExtra(request);
  
let formData = await request.json();

    if(formData.deleteObject){
      await metaobject.delete(formData.objectId);
    }

    return ({
      status: {
        success: true,
        message: "Content deleted successfully",
      }
    });
}

export default function DiscountsPage() {
  return <Discounts />;
}
